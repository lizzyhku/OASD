# -*- coding: utf-8 -*-
"""
Created on Thu Aug 19 14:33:04 2021

@author: wang_zheng
"""

import numpy as np
import time
import data_utils as F
from data_utils import G, SD_pair_ref, historical_average_coordinate, my_fscore, my_fscore_unify, my_fscore_unify_with_a_threshold
import networkx as nx
import pickle
from frechetdist import frechet
from collections import deque
from collections import namedtuple
import matplotlib.pyplot as plt

P=[[1.1,1.2], [2,1], [2,2]]
Q=[[2.1,2.2], [2,1], [2,2]]
print(frechet(P,Q))

traj_chengdu_path = 'C:/Users/wang_zheng/Downloads/HP-backup/compression-data/chengdu-pickle/PN/efficiency_group_data/'
traj_chengdu_path = 'C:/Users/wang_zheng/Downloads/HP-backup/compression-data/chengdu-pickle/'
traj_chengdu_path = 'C:/Users/wang_zheng/Downloads/HP-backup/compression-data/xian-pickle/PN/efficiency_group_data/'
traj_chengdu_path = 'C:/Users/wang_zheng/Downloads/HP-backup/compression-data/chengdu-pickle/'
#traj_chengdu_path = 'C:/Users/Wang Zheng/Downloads/pn/'

vis_path = 'C:/Users/wang_zheng/Downloads/HP-backup/compression-data/chengdu-pickle/vis/'

np.random.seed(0)

globaltime = str(time.time())
records = {}
def get_traj_with_coor(route):
    coorT = []
    for r in route:
        if r not in historical_average_coordinate:
            coorT.append(t_)
        else:
            t_ = historical_average_coordinate[r]
            coorT.append(t_)
    return coorT

def get_similarity_(partial, reference):
    #print('partial, reference', partial, reference)
    if partial[-1] == reference[-1]:
        return get_similarity_last(partial, reference), reference[-1]
    queue = []
    queue.append(partial[-1])
    looked = set()
    looked.add(partial[-1])
    while(len(queue)>0):
        temp = queue.pop(0)
        nodes = G.successors(temp)
        for w in nodes:
            if w not in looked:
                queue.append(w)
                looked.add(w)
                if w in reference:
                    #print('partial[-1], w', partial[-1], w)
                    fid = reference.index(w)
                    par_complete = partial + reference[fid:]
                    if (tuple(par_complete), tuple(reference)) not in records:
                        parT = get_traj_with_coor(par_complete)
                        refT = get_traj_with_coor(reference)
                        similarity = frechet(parT,refT)
                        records[(tuple(par_complete), tuple(reference))] = similarity
                        #print((tuple(par_complete), tuple(reference)))
                        #print('1', similarity)
                        return similarity, w
                    else:
                        #print((tuple(par_complete), tuple(reference)))
                        #print('2', records[(tuple(par_complete), tuple(reference))])
                        return records[(tuple(par_complete), tuple(reference))], w
        #print(temp, end=' ')

def get_similarity(partial, reference):  # 开始节点  目标节点 图字典
    if partial[-1] == reference[-1]:
        return get_similarity_last(partial, reference), reference[-1]
    
    node = namedtuple('node', 'name, from_node')    # 使用namedtuple定义节点，用于存储前置节点
    search_queue = deque()  # 使用双端队列，这里当作队列使用，根据先进先出获取下一个遍历的节点
    name_search = deque()   # 存储队列中已有的节点名称
    visited = {}            # 存储已经访问过的节点
    start_node = partial[-1]
    search_queue.append(node(start_node, None))  # 填入初始节点，从队列后面加入
    name_search.append(start_node)               # 填入初始节点名称
    path = []               # 用户回溯路径
    path_len = 0            # 路径长度
    
    #print('开始搜索...')
    while search_queue:     # 只要搜索队列中有数据就一直遍历下去
        #print('待遍历节点: ', name_search)
        current_node = search_queue.popleft()  # 从队列前边获取节点，即先进先出，这是BFS的核心
        name_search.popleft()                  # 将名称也相应弹出
        if current_node.name not in visited:   # 当前节点是否被访问过
            #print('当前节点: ', current_node.name, end=' | ')
            if current_node.name in reference:  # 退出条件，找到了目标节点，接下来执行路径回溯和长度计算
                pre_node = current_node        # 路径回溯的关键在于每个节点中存储的前置节点
                while True:                    # 开启循环直到找到开始节点
                    if pre_node.name == start_node:  # 退出条件：前置节点为开始节点
                        path.append(start_node)      # 退出前将开始节点也加入路径，保证路径的完整性
                        break
                    else:
                        path.append(pre_node.name)   # 不断将前置节点名称加入路径
                        pre_node = visited[pre_node.from_node]  # 取出前置节点的前置节点，依次类推
                path = path[::-1][1:-1]
                path_len = len(path)       # 获得完整路径后，长度即为节点个数-1
                fid = reference.index(current_node.name)
                #print('--', partial, path, reference[fid:], path_len)
                
                if path_len == 0:
                    if partial[-1] == reference[fid]:
                        par_complete = partial + reference[fid+1:]
                    else:
                        par_complete = partial + reference[fid:]
                else:
                    par_complete = partial + path + reference[fid:]
                #print('par_complete', par_complete)
                
                if (tuple(par_complete), tuple(reference)) not in records:
                    parT = get_traj_with_coor(par_complete)
                    refT = get_traj_with_coor(reference)
                    similarity = frechet(parT,refT)
                    records[(tuple(par_complete), tuple(reference))] = similarity
                    #print((tuple(par_complete), tuple(reference)))
                    #print('1', similarity)
                    return similarity, current_node.name
                else:
                    #print((tuple(par_complete), tuple(reference)))
                    #print('2', records[(tuple(par_complete), tuple(reference))])
                    return records[(tuple(par_complete), tuple(reference))], current_node.name
            else:
                visited[current_node.name] = current_node   # 如果没有找到目标节点，将节点设为已访问，并将相邻节点加入搜索队列，继续找下去
                for node_name in G.successors(current_node.name):  # 遍历相邻节点，判断相邻节点是否已经在搜索队列
                    if node_name not in name_search:        # 如果相邻节点不在搜索队列则进行添加
                        search_queue.append(node(node_name, current_node.name))
                        name_search.append(node_name)
    

def get_similarity_last(partial, reference):
    if (tuple(partial), tuple(reference)) not in records:
        parT = get_traj_with_coor(partial)
        refT = get_traj_with_coor(reference)
        #print(parT, refT)
        similarity = frechet(parT,refT)
        records[(tuple(partial), tuple(reference))] = similarity
        return similarity
    else:
        return records[(tuple(partial), tuple(reference))]

'''
for i in [('g1_data.pickle','g1_label.pickle')]:
    
    TEXT_TEST = pickle.load(open(traj_chengdu_path+i[0], 'rb'), encoding='bytes')[:200]
    LABEL_TEST = pickle.load(open(traj_chengdu_path+i[1], 'rb'), encoding='bytes')[:200]
    
    records = {}
    start = time.time()
    labelling_prauc = []
    detoutc = 0         
    Label_Test, Output_Score = [], [] 
    for label_test, text_test in zip(LABEL_TEST, TEXT_TEST):
        text_test = list(text_test)
        if sum(label_test) > 0:
            detoutc += 1
            outputs = []
            find_base = []
            ref_traj = SD_pair_ref[(text_test[0], text_test[-1])]
            #print('ref_traj', ref_traj)
            for i in range(len(text_test)):
                similarity, find = get_similarity(text_test[:i+1], ref_traj)
                find_base.append(find)
                outputs.append(similarity)
            #print('outputs find', outputs, find_base)
            Label_Test.append(label_test)
            Output_Score.append(outputs)
            #labelling_prauc.append(my_fscore(label_test, np.array(outputs), 'soft'))
            #print('label_test', label_test)
            #println()
    #print('labelling =', sum(labelling_prauc)/len(labelling_prauc), detoutc)
    print('time', (time.time()-start)/len(TEXT_TEST))
    print('unify thres labelling = ', my_fscore_unify(Label_Test, Output_Score))
'''
'''
for i in [('g1_data.pickle','g1_label.pickle'),
          ('g2_data.pickle','g2_label.pickle'),
          ('g3_data.pickle','g3_label.pickle'),
          ('g4_data.pickle','g4_label.pickle')]:
    
    TEXT_TEST = pickle.load(open(traj_chengdu_path+i[0], 'rb'), encoding='bytes')
    LABEL_TEST = pickle.load(open(traj_chengdu_path+i[1], 'rb'), encoding='bytes')
    
    records = {}
    start = time.time()
    labelling_prauc = []
    detoutc = 0         
    Label_Test, Output_Score = [], [] 
    for label_test, text_test in zip(LABEL_TEST, TEXT_TEST):
        text_test = list(text_test)
        if sum(label_test) > 0:
            detoutc += 1
            outputs = []
            find_base = []
            if (text_test[0], text_test[-1]) not in SD_pair_ref:
                print('none')
                continue
            ref_traj = SD_pair_ref[(text_test[0], text_test[-1])]
            #print('ref_traj', ref_traj)
            for i in range(len(text_test)):
                similarity, find = get_similarity(text_test[:i+1], ref_traj)
                find_base.append(find)
                outputs.append(similarity)
            #print('outputs find', outputs, find_base)
            Label_Test.append(label_test)
            Output_Score.append(outputs)
            #labelling_prauc.append(my_fscore(label_test, np.array(outputs), 'soft'))
            #print('label_test', label_test)
            #println()
    #print('labelling =', sum(labelling_prauc)/len(labelling_prauc), detoutc)
    print('time', (time.time()-start)/len(TEXT_TEST))
    print('unify thres labelling = ', my_fscore_unify(Label_Test, Output_Score))
    #print('unify thres labelling = ', my_fscore_unify_with_a_threshold(Label_Test, Output_Score, 1.4539134655589228e-05))
    # labelling = 0.6647404324052204 20   
    # my_prauc labelling = 0.40858405324043 20
    # my_fscore 0.688642870769943 20
    # unify thres labelling =  0.7063710901671424 (0.7245557820315885)
    #unify thres labelling =  0.7271577396751274
'''
'''
for i in ['lerned-classifier-data2', 'lerned-classifier-data3', 'lerned-classifier-data4', 'lerned-classifier-data5']:
    
    [LABEL_TEST, TEXT_TEST] = pickle.load(open(traj_chengdu_path+i, 'rb'), encoding='bytes')
    
    records = {}
    start = time.time()
    labelling_prauc = []
    detoutc = 0         
    Label_Test, Output_Score = [], [] 
    for label_test, text_test in zip(LABEL_TEST, TEXT_TEST):
        text_test = list(text_test)
        if sum(label_test) > 0:
            detoutc += 1
            outputs = []
            find_base = []
            ref_traj = SD_pair_ref[(text_test[0], text_test[-1])]
            #print('ref_traj', ref_traj)
            for i in range(len(text_test)):
                similarity, find = get_similarity(text_test[:i+1], ref_traj)
                find_base.append(find)
                outputs.append(similarity)
            #print('outputs find', outputs, find_base)
            Label_Test.append(label_test)
            Output_Score.append(outputs)
            #labelling_prauc.append(my_fscore(label_test, np.array(outputs), 'soft'))
            #print('label_test', label_test)
            #println()
    #print('labelling =', sum(labelling_prauc)/len(labelling_prauc), detoutc)
    print('time', (time.time()-start))
    #print('unify thres labelling = ', my_fscore_unify_with_a_threshold(Label_Test, Output_Score, 1.4539134655589228e-05))
    # labelling = 0.6647404324052204 20   
    # my_prauc labelling = 0.40858405324043 20
    # my_fscore 0.688642870769943 20
    # unify thres labelling =  0.7063710901671424 (0.7245557820315885)
    #unify thres labelling =  0.7271577396751274
'''    
import os
historical_average_coordinate = pickle.load(open(traj_chengdu_path+'historical_average_coordinate', 'rb'), encoding='bytes')
groundtruth_path = 'C:/Users/wang_zheng/Downloads/HP-backup/compression-data/chengdu-pickle/manually_v2-refine/'

def get_file_path(root_path,file_list,dir_list):
    dir_or_files = os.listdir(root_path)
    for dir_file in dir_or_files:
        dir_file_path = os.path.join(root_path,dir_file)
        if os.path.isdir(dir_file_path):
            dir_list.append(dir_file_path)
            get_file_path(dir_file_path,file_list,dir_list)
        else:
            file_list.append(dir_file_path)
    return file_list, dir_list

def obtain_groundtruth():
    file_list = []
    dir_list = []
    groundtruth_table = {}
    file_list, dir_list = get_file_path(groundtruth_path, file_list, dir_list)
    for fl in file_list:
        tmp = fl.split(groundtruth_path)[1]
        if '.txt' not in tmp:
            continue
        tmp_ = tmp.split('_')
        S, D, slot, num = int(tmp_[0]), int(tmp_[1]), int(tmp_[2]), int(tmp_[3])
        #print('fl', fl)
        f = open(fl)
        line_count = 0
        token, traj, label, flag = [], [], [], False
        for line in f:
            line_count+=1
            if line_count == 1:
                pathnum = int(line.split(' ')[4])
                continue
            temp = line.strip().split(',')
            if int(temp[0]) in historical_average_coordinate:
                traj.append(historical_average_coordinate[int(temp[0])])
                token.append(int(temp[0]))
            else:
                #print('miss', int(temp[0]))
                flag = True
                break
            label.append(int(temp[1]))
        f.close()
        if flag:
            continue
        if (S,D) not in groundtruth_table:
            groundtruth_table[(S,D)] = [[token, traj, label, pathnum]]
        else:
            groundtruth_table[(S,D)].append([token, traj, label, pathnum])
    #print('There are {} detours (with {} abnormal raods) in total {} paths (with {} roads)'.format(NUM_detour,abroads,NUM,roads))
    return groundtruth_table

def draw_block(name, draw_normal, best_item, control=1):
    plt.figure(figsize=(10.5/2,6.8/2))
    c = 0
    for items in draw_normal:
        if c == control:
            break
        [token, traj, label, pathnum] = items
        traj = np.array(traj)
        plt.plot(traj[:,0], traj[:,1], color="blue", linewidth = 4, label='normal route', alpha=0.4)
        c += 1
        print('normal label', label)
    #plt.annotate('S', (traj[0][0],traj[0][1]), fontsize = 15)
    #plt.annotate('D', (traj[-1][0],traj[-1][1]), fontsize = 15)
    #print(traj[0],traj[-1])
    plt.text(traj[0][0],traj[0][1], "S", ha="center", va="center", size=11,
    bbox=dict(boxstyle="square, pad=0.25", fc="w", lw=2, alpha=0.8))
    plt.text(traj[-1][0],traj[-1][1], "D", ha="center", va="center", size=11,
    bbox=dict(boxstyle="square, pad=0.25", fc="w", lw=2, alpha=0.8))
    
    [token, traj, label, pathnum] = best_item
    traj = np.array(traj)
    plt.plot(traj[:,0],traj[:,1], color="red", marker='o', linewidth = 2, linestyle='dashed', label='detour route', alpha=0.6)
    #plt.scatter(traj[:,0],traj[:,1], color="red", s=20)
    
    print('label', label)
    detour = []
    flag = True
    for l in range(1, len(traj)):
        if label[l-1] != label[l]:
            detour.append(l-1)
        if len(detour) == 2: 
            #print(detour)
            s, d = detour[0], detour[1]+1
            if flag:
                plt.plot(traj[s:d+1,0],traj[s:d+1,1], color="green", linewidth = 9,  label='labeled detour', alpha=0.3)
                flag = False
            else:
                plt.plot(traj[s:d+1,0],traj[s:d+1,1], color="green", linewidth = 9,  alpha=0.3)
            detour = []
       
    #plt.scatter(np.array(sim_traj)[:,0],np.array(sim_traj)[:,1],color="red", s=20)
    plt.title('SD-Pair: ({}, {})'.format(S, D))
    #plt.axis('off')
    #plt.xticks([])
    #plt.yticks([])
    plt.legend(loc='best', prop = {'size': 12})
    plt.savefig(name, format='pdf', dpi=1000)
    #plt.savefig(name, format='png')

def draw(name, trajs):
    draw_normal, best, Best_Item = [], 0, []
    for items in trajs:
        if len(items) == 4:
            [token, traj, label, pathnum] = items
        if len(items) == 5:
            [token, traj, label_, pathnum, label] = items
        tmp = sum(label) 
        if tmp == 0 and pathnum > 10:
            if len(items) == 4:
                draw_normal.append(items)
            if len(items) == 5:
                draw_normal.append([token, traj, label, pathnum])
        elif tmp > 0:
            if len(items) == 4:
                Best_Item.append(items)
            if len(items) == 5:
                Best_Item.append([token, traj, label, pathnum])
    
    for i in range(len(Best_Item)):
        #print(label)
        draw_block(name+'-'+str(i)+'.pdf', draw_normal, Best_Item[i])


#groundtruth_table = obtain_groundtruth()
#pickle.dump(groundtruth_table, open(traj_chengdu_path+'case_study', 'wb'), protocol=2)
groundtruth_table = pickle.load(open(traj_chengdu_path+'case_study', 'rb'), encoding='bytes')
#(S,D)=list(groundtruth_table.keys())[0]
(S,D)=(209,2027)
(S,D)=(1000,180)

#209,2027
#(209,2027)-2

pn_table = pickle.load(open(traj_chengdu_path+'case_list_cokmbine.pickle', 'rb'), encoding='bytes')

#draw(vis_path+'ground-'+str(S)+'-'+str(D), groundtruth_table[(S,D)])
#draw(vis_path+'pn-'+str(S)+'-'+str(D), pn_table[(S,D)])

ctss_table = {}
detoutc = 0  
ctss_table[(S,D)] = []
pn_table[(S,D)] = []
Similarity = []
for item in groundtruth_table[(S,D)]:
    #print('item',item)
    [text_test, traj, label_test, fre] = item
    if sum(label_test) > 0:
        detoutc += 1
        outputs = []
        find_base = []
        if (text_test[0], text_test[-1]) not in SD_pair_ref:
            print('none')
            continue
        ref_traj = SD_pair_ref[(text_test[0], text_test[-1])]
        #print('ref_traj', ref_traj)
        tmp_simi=[]
        for i in range(len(text_test)):
            similarity, find = get_similarity(text_test[:i+1], ref_traj)
            tmp_simi.append(similarity)
            find_base.append(find) #1.4539134655589228e-05
            if similarity < 0.0023001842813694367 or i == 0 or i == len(text_test)-1:
                outputs.append(0)
            else:
                outputs.append(1)
        Similarity.append(tmp_simi)
    else:
        outputs = [0]*len(text_test)
    ctss_table[(S,D)].append([text_test, traj, outputs, fre])

draw(vis_path+'ctss-'+str(S)+'-'+str(D), ctss_table[(S,D)])

#[(1000,1884)][2][-2] 3, 30
# [(1000,1884)][2][-2]  ctss 6, 35
#(1025,1019), 1, 4
# 2 18 22 25 groundtruth_table[(209,2027)][3][-2] (ctss 5 25)
#a = groundtruth_table[(1000,1884)][2][-2]
#(1000, 180, ground) 15 23 
#(1000, 180, ctss) 17 24
#a = ctss_table[(1000,1884)][2][-2]
#for i in range(1, len(a)):
#    if a[i]==1 and a[i-1]==0:
#        print(i)
#    if a[i]==0 and a[i-1]==1:
#        print(i+1)
    
    
    
    
    
    
    
    
    
    
    
    
    
    