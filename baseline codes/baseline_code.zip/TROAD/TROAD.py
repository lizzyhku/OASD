# -*- coding: utf-8 -*-
"""
Created on Sun Oct 17 00:15:48 2021

@author: wang_zheng
"""

import numpy as np
import time
import data_utils as F
from data_utils import historical_average_coordinate
import pickle
import math

traj_chengdu_path = 'C:/Users/wang_zheng/Downloads/HP-backup/compression-data/chengdu-pickle/PN/efficiency_group_data/'
traj_chengdu_path = 'C:/Users/wang_zheng/Downloads/HP-backup/compression-data/chengdu-pickle/'
traj_chengdu_path = 'C:/Users/wang_zheng/Downloads/HP-backup/compression-data/xian-pickle/PN/efficiency_group_data/'


np.random.seed(0)

globaltime = str(time.time())

#TEXT_TEST = pickle.load(open(traj_chengdu_path+'val_data.pickle', 'rb'), encoding='bytes')
#LABEL_TEST = pickle.load(open(traj_chengdu_path+'val_label.pickle', 'rb'), encoding='bytes')

def get_traj_with_coor(route):
    coorT = []
    for r in route:
        if r not in historical_average_coordinate:
            coorT.append(t_)
        else:
            t_ = historical_average_coordinate[r]
            coorT.append(t_)
    return coorT

#Detection step
def degree(vec1, vec2):
    x=np.array(vec1)
    y=np.array(vec2)
    Lx=np.sqrt(x.dot(x))
    Ly=np.sqrt(y.dot(y))
    cos_angle=x.dot(y)/(Lx*Ly)
    angle=np.arccos(cos_angle)
    angle2=angle*360/2/np.pi
    return angle2

def ped_op(segment):
    if len(segment) <= 2:
        #print('segment error', 0.0)
        return 0.0
    else:
        ps = segment[0]
        pe = segment[-1]
        e = 0.0
        for i in range(1,len(segment)-1):
            pm = segment[i]
            A = pe[1] - ps[1]
            B = ps[0] - pe[0]
            C = pe[0] * ps[1] - ps[0] * pe[1]
            if A == 0 and B == 0:
                e = max(e, 0.0)
            else:
                e = max(e, abs((A * pm[0] + B * pm[1] + C)/ np.sqrt(A * A + B * B)))
        #print('segment error', e)
        return e

def ped_min(point, line_p1, line_p2):
     x0 = point[0]
     y0 = point[1]
     x1 = line_p1[0]
     y1 = line_p1[1]
     x2 = line_p2[0]
     y2 = line_p2[1]
     k = -((x1 - x0) * (x2 - x1) + (y1 - y0) * (y2 - y1)) / \
         ((x2 - x1) ** 2 + (y2 - y1) ** 2)*1.0
     xn = k * (x2 - x1) + x1
     yn = k * (y2 - y1) + y1
     return min(np.linalg.norm(np.array([xn, yn])-np.array([x1, y1])),np.linalg.norm(np.array([xn, yn])-np.array([x2, y2]))) 
    
def partition_dist(long_subt,short_subt):
    long_s, long_e, short_s, short_e = np.array(long_subt[0]), np.array(long_subt[-1]), np.array(short_subt[0]), np.array(short_subt[-1])
    degree_ = degree(long_e-long_s, short_e-short_s)
    # degree_dist
    if degree_ >= 0 and degree_ < 90:
        degree_dist = np.sin(degree_*np.pi/180)*np.linalg.norm(short_e-short_s)
    else:
        degree_dist = np.linalg.norm(short_e-short_s)
    # ped_dist
    L1, L2 = ped_op([long_subt[0],short_subt[0],long_subt[-1]]), ped_op([long_subt[0],short_subt[-1],long_subt[-1]])
    if (L1+L2) == 0:
        ped_dist = 0
    else:
        ped_dist = (L1*L1+L2*L2)/(L1+L2)
    # min_dist
    min_dist = min(ped_min(short_subt[0],long_subt[0],long_subt[-1]),
                   ped_min(short_subt[-1],long_subt[0],long_subt[-1]))
    return 1.0*degree_dist + 1.0*ped_dist + 1.0*min_dist    


for i in [('g1_data.pickle','g1_label.pickle'),
          ('g2_data.pickle','g2_label.pickle'),
          ('g3_data.pickle','g3_label.pickle'),
          ('g4_data.pickle','g4_label.pickle')]:
    
    TEXT_TEST = pickle.load(open(traj_chengdu_path+i[0], 'rb'), encoding='bytes')
    LABEL_TEST = pickle.load(open(traj_chengdu_path+i[1], 'rb'), encoding='bytes')
    
    TR = []
    for text_test in TEXT_TEST:
        TR.append(get_traj_with_coor(text_test))
    
    _pts_dis = []
    for tr in TR:
        for i in range(1, len(tr)):
            _pts_dis.append(np.linalg.norm(np.array(tr[i])-np.array(tr[i-1])))
    
    partition_thres = np.mean(_pts_dis)*2
    distancce_thres = np.mean(_pts_dis)/4
    P = 0.65
    F_ratio = 0.2
    #print('average dist', partition_thres)
    
    #Partition step
    T_Partition = []
    
    for tr in TR:
        T_ = []
        sum_ = 0
        S_ = 0
        for i in range(1, len(tr)):
            sum_ += np.linalg.norm(np.array(tr[i])-np.array(tr[i-1]))
            if sum_ < partition_thres:
                continue
            else:
                sum_ = 0
                T_.append((S_,i))
                S_ = i
        if T_ == []:
            T_.append((0, len(tr)-1))
        if T_[-1][1] != len(tr)-1:
            T_.append((T_[-1][1],len(tr)-1))
        T_Partition.append(T_)
        
    start = time.time()
    
    partition_dist_container = {}
    for i in range(len(TR)):
        #if i%100 == 0:
        #    print('process', i)
        for Li in T_Partition[i]:
            for j in range(i, len(TR)):
                for Lj in T_Partition[j]:
                    len_Li = np.linalg.norm(np.array(TR[i][Li[0]])-np.array(TR[i][Li[1]]))
                    len_Lj = np.linalg.norm(np.array(TR[j][Lj[0]])-np.array(TR[j][Lj[1]]))
                    if len_Li < len_Lj:
                        continue
                    else:
                        tmp = partition_dist(TR[i][Li[0]:Li[1]+1],TR[j][Lj[0]:Lj[1]+1])
                        if np.isnan(tmp) == True:
                            partition_dist_container[(i,Li,j,Lj)] = 0.0
                        else:
                            partition_dist_container[(i,Li,j,Lj)] = tmp  
    #pickle.dump(partition_dist_container, open(traj_chengdu_path+'partition_dist_container', 'wb'), protocol=2)
    
    #time 0.15857577323913574 by TR[:10]
    #time 0.3929460048675537 by TR[:20]
    #time 0.9215373992919922 by TR[:30]
    #time 1.876986026763916 by TR[:40]
    #time 9.281702518463135 by TR[:100]
    #time 1506.5084493160248 second by TR[:]
    
    #partition_dist_container = pickle.load(open(traj_chengdu_path+'partition_dist_container', 'rb'), encoding='bytes')
    arr_std = np.std(list(partition_dist_container.values()), ddof=1)
    
    density = {}
    adj = {}
    CTR = {}
    for i in range(len(TR)):
        #if i%100 == 0:
        #    print('process', i)
        for Li in T_Partition[i]:
            counter = 0 
            counter_ = 0
            for j in range(i, len(TR)):
                flag = False
                for Lj in T_Partition[j]:
                    len_Li = np.linalg.norm(np.array(TR[i][Li[0]])-np.array(TR[i][Li[1]]))
                    len_Lj = np.linalg.norm(np.array(TR[j][Lj[0]])-np.array(TR[j][Lj[1]]))
                    if len_Li < len_Lj:
                        continue
                    else:
                        tmp = partition_dist_container[(i,Li,j,Lj)]
                        #print(tmp, arr_std)
                        if tmp <= arr_std:
                            counter += 1                       
                        if tmp <= distancce_thres:
                            flag = True
                if flag:
                    counter_ += 1
            CTR[(i, Li)] = counter_
            density[(i, Li)] = counter
    
    density_sum = 0
    for key in density:
        density_sum += density[key]
    for key in density:
        adj[key] = density_sum/len(density)/density[key]
    #pickle.dump(CTR, open(traj_chengdu_path+'CTR', 'wb'), protocol=2)
    #pickle.dump(density, open(traj_chengdu_path+'density', 'wb'), protocol=2)
    #pickle.dump(adj, open(traj_chengdu_path+'adj', 'wb'), protocol=2)
    #CTR = pickle.load(open(traj_chengdu_path+'CTR', 'rb'), encoding='bytes')
    #density = pickle.load(open(traj_chengdu_path+'density', 'rb'), encoding='bytes')
    #adj = pickle.load(open(traj_chengdu_path+'adj', 'rb'), encoding='bytes')
    
    Mark = {}
    for i in range(len(TR)):
        #if i%100 == 0:
        #    print('process', i)
        for Li in T_Partition[i]:
            #print(CTR[(i, Li)], adj[(i, Li)], (1-P)*len(TR))
            if math.ceil(CTR[(i, Li)]*adj[(i, Li)]) <= math.ceil((1-P)*len(TR)):
                Mark[(i, Li)] = True
    
    LABEL_PRED = []
    for i in range(len(TR)):
        len_sum = 0
        len_detour = 0
        label_pred = [0]*T_Partition[i][-1][1]
        for Li in T_Partition[i]:
            tmp = np.linalg.norm(np.array(TR[i][Li[0]])-np.array(TR[i][Li[1]]))
            len_sum += tmp
            if (i, Li) in Mark:
                if Mark[(i, Li)]:
                    len_detour += tmp
                    label_pred[Li[0]:Li[1]+1] = [1]*(Li[1]-Li[0])
        #print(len_detour/len_sum, F_ratio)
        if len_detour/len_sum >= F_ratio:
            label_pred[0], label_pred[-1] = 0, 0
            #print('detour', label_pred)
            LABEL_PRED.append(label_pred)
        else:
            LABEL_PRED.append([0]*T_Partition[i][-1][1])
    
    labelling = F.my_fscore_whole_determine(LABEL_TEST, LABEL_PRED)
    print('time', (time.time()-start)/len(TEXT_TEST))
    print('labelling', labelling)
    #labelling 0.48061137266863035

'''
for i in [50,100,150,200,250]:
    
    [LABEL_TEST, TEXT_TEST] = pickle.load(open(traj_chengdu_path+'lerned-classifier-data', 'rb'), encoding='bytes')[0:i]
    LABEL_TEST, TEXT_TEST = LABEL_TEST[:i], TEXT_TEST[:i]
    
    TR = []
    for text_test in TEXT_TEST:
        TR.append(get_traj_with_coor(text_test))
    
    _pts_dis = []
    for tr in TR:
        for i in range(1, len(tr)):
            _pts_dis.append(np.linalg.norm(np.array(tr[i])-np.array(tr[i-1])))
    
    partition_thres = np.mean(_pts_dis)*5
    distancce_thres = np.mean(_pts_dis)/4
    P = 0.65
    F_ratio = 0.2
    #print('average dist', partition_thres)
    
    #Partition step
    T_Partition = []
    
    for tr in TR:
        T_ = []
        sum_ = 0
        S_ = 0
        for i in range(1, len(tr)):
            sum_ += np.linalg.norm(np.array(tr[i])-np.array(tr[i-1]))
            if sum_ < partition_thres:
                continue
            else:
                sum_ = 0
                T_.append((S_,i))
                S_ = i
        if T_ == []:
            T_.append((0, len(tr)-1))
        if T_[-1][1] != len(tr)-1:
            T_.append((T_[-1][1],len(tr)-1))
        T_Partition.append(T_)
        
    start = time.time()
    
    partition_dist_container = {}
    for i in range(len(TR)):
        #if i%100 == 0:
        #    print('process', i)
        for Li in T_Partition[i]:
            for j in range(i, len(TR)):
                for Lj in T_Partition[j]:
                    len_Li = np.linalg.norm(np.array(TR[i][Li[0]])-np.array(TR[i][Li[1]]))
                    len_Lj = np.linalg.norm(np.array(TR[j][Lj[0]])-np.array(TR[j][Lj[1]]))
                    if len_Li < len_Lj:
                        continue
                    else:
                        tmp = partition_dist(TR[i][Li[0]:Li[1]+1],TR[j][Lj[0]:Lj[1]+1])
                        partition_dist_container[(i,Li,j,Lj)] = tmp  
    #pickle.dump(partition_dist_container, open(traj_chengdu_path+'partition_dist_container', 'wb'), protocol=2)
    
    #time 0.15857577323913574 by TR[:10]
    #time 0.3929460048675537 by TR[:20]
    #time 0.9215373992919922 by TR[:30]
    #time 1.876986026763916 by TR[:40]
    #time 9.281702518463135 by TR[:100]
    #time 1506.5084493160248 second by TR[:]
    
    #partition_dist_container = pickle.load(open(traj_chengdu_path+'partition_dist_container', 'rb'), encoding='bytes')
    arr_std = np.std(list(partition_dist_container.values()), ddof=1)
    
    density = {}
    adj = {}
    CTR = {}
    for i in range(len(TR)):
        #if i%100 == 0:
        #    print('process', i)
        for Li in T_Partition[i]:
            counter = 0 
            counter_ = 0
            for j in range(i, len(TR)):
                flag = False
                for Lj in T_Partition[j]:
                    len_Li = np.linalg.norm(np.array(TR[i][Li[0]])-np.array(TR[i][Li[1]]))
                    len_Lj = np.linalg.norm(np.array(TR[j][Lj[0]])-np.array(TR[j][Lj[1]]))
                    if len_Li < len_Lj:
                        continue
                    else:
                        tmp = partition_dist_container[(i,Li,j,Lj)]
                        if tmp <= arr_std:
                            counter += 1                       
                        if tmp <= distancce_thres:
                            flag = True
                if flag:
                    counter_ += 1
            CTR[(i, Li)] = counter_
            density[(i, Li)] = counter
    
    density_sum = 0
    for key in density:
        density_sum += density[key]
    for key in density:
        adj[key] = density_sum/len(density)/density[key]
    #pickle.dump(CTR, open(traj_chengdu_path+'CTR', 'wb'), protocol=2)
    #pickle.dump(density, open(traj_chengdu_path+'density', 'wb'), protocol=2)
    #pickle.dump(adj, open(traj_chengdu_path+'adj', 'wb'), protocol=2)
    #CTR = pickle.load(open(traj_chengdu_path+'CTR', 'rb'), encoding='bytes')
    #density = pickle.load(open(traj_chengdu_path+'density', 'rb'), encoding='bytes')
    #adj = pickle.load(open(traj_chengdu_path+'adj', 'rb'), encoding='bytes')
    
    Mark = {}
    for i in range(len(TR)):
        #if i%100 == 0:
        #    print('process', i)
        for Li in T_Partition[i]:
            #print(CTR[(i, Li)], adj[(i, Li)], (1-P)*len(TR))
            if math.ceil(CTR[(i, Li)]*adj[(i, Li)]) <= math.ceil((1-P)*len(TR)):
                Mark[(i, Li)] = True
    
    LABEL_PRED = []
    for i in range(len(TR)):
        len_sum = 0
        len_detour = 0
        label_pred = [0]*T_Partition[i][-1][1]
        for Li in T_Partition[i]:
            tmp = np.linalg.norm(np.array(TR[i][Li[0]])-np.array(TR[i][Li[1]]))
            len_sum += tmp
            if (i, Li) in Mark:
                if Mark[(i, Li)]:
                    len_detour += tmp
                    label_pred[Li[0]:Li[1]+1] = [1]*(Li[1]-Li[0])
        #print(len_detour/len_sum, F_ratio)
        if len_detour/len_sum >= F_ratio:
            label_pred[0], label_pred[-1] = 0, 0
            #print('detour', label_pred)
            LABEL_PRED.append(label_pred)
        else:
            LABEL_PRED.append([0]*T_Partition[i][-1][1])
    
    #labelling = F.my_fscore_whole_determine(LABEL_TEST, LABEL_PRED)
    print('time', (time.time()-start))
    #print('labelling', labelling)
    #labelling 0.48061137266863035
'''