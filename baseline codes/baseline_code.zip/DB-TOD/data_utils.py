import pickle
import numpy as np
import networkx as nx
import time
import random
from gensim.models import Word2Vec
import gensim
import matplotlib.pyplot as plt
import os
from sklearn.metrics import precision_recall_curve, auc
import math
from itertools import groupby

random.seed(0)
slot = 24
traj_chengdu_path = 'C:/Users/wang_zheng/Downloads/HP-backup/compression-data/xian-pickle/'
#transition_proba = pickle.load(open(traj_chengdu_path+'transition_proba_'+str(slot), 'rb'), encoding='bytes')
G = nx.read_adjlist(traj_chengdu_path+"xian.adjlist", create_using=nx.DiGraph, nodetype=int)
data_dict_chengdu = pickle.load(open(traj_chengdu_path+'data_dict_xian.pickle', 'rb'), encoding='bytes')
nodetype = pickle.load(open(traj_chengdu_path+'roadidx_type_5.pickle', 'rb'), encoding='bytes')


SD_pair_data = pickle.load(open(traj_chengdu_path+'SD_pair_data_'+str(slot), 'rb'), encoding='bytes')
#SD_pair_time = pickle.load(open(traj_chengdu_path+'SD_pair_time_'+str(slot), 'rb'), encoding='bytes')
#SD_pair_angle = pickle.load(open(traj_chengdu_path+'SD_pair_angle', 'rb'), encoding='bytes')
#SD_pair_key = pickle.load(open(traj_chengdu_path+'SD_pair_key', 'rb'), encoding='bytes')
historical_average_speed = pickle.load(open(traj_chengdu_path+'historical_average_speed', 'rb'), encoding='bytes')
historical_average_angle = pickle.load(open(traj_chengdu_path+'historical_average_angle', 'rb'), encoding='bytes')
#sample_table = pickle.load(open(traj_chengdu_path+'SD_pair_'+str(slot)+'_sample_table', 'rb'), encoding='bytes')
#groundtruth_path = 'C:/Users/wang_zheng/Downloads/HP-backup/compression-data/xian-pickle/manually-refine/'
#groundtruth_table = pickle.load(open(traj_chengdu_path+'groundtruth_table_'+str(slot), 'rb'), encoding='bytes')

def my_prauc(y_true, y_score, flag='soft'):
    y_true, y_score = y_true[1:-1], y_score[1:-1]
    precision, recall = [], []
    #distinct_value_indices = np.where(np.diff(y_score))[0]
    #threshold_idxs = np.r_[distinct_value_indices, len(y_score)-1]
    #threshold = np.array(y_score)[threshold_idxs]
    #print('threshold',threshold)
    y_score = list(y_score.reshape(-1))
    fun = lambda x: x[1] - x[0]
    listA = []
    lstA = [i for i,v in enumerate(y_true) if v==1]
    for k, g in groupby(enumerate(lstA), fun):
        listA.append([v for i, v in g])
    ground_num = len(listA)
    if ground_num == 0:
        return 0.0
    listA = sum(listA, [])
    #print('listA', listA)
    for the in y_score:
        listB = []
        tmp =  [1 if s >= the else 0 for s in y_score]
        lstB = [i for i,v in enumerate(tmp) if v==1]
        for k, g in groupby(enumerate(lstB), fun):
            listB.append([v for i, v in g])
        #print(the, y_score, tmp, lstB, listB)
        pred_num = len(listB)
        if flag == 'strict':
            correct_num = int(listA==listB)
        if flag == 'soft':
            listB = sum(listB, [])
            correct_num = len(set(listA).intersection(set(listB)))/len(set(listA).union(set(listB)))
            #print('correct_num', correct_num, pred_num, ground_num)
        precision.append(correct_num/pred_num)
        recall.append(correct_num/ground_num)
    precision.append(1)
    recall.append(0)
    #print(np.array(recall), np.array(precision))
    return auc(np.array(recall), np.array(precision), reorder=True)

def my_fscore(y_true, y_score, flag='soft'):
    y_true, y_score = y_true[1:-1], y_score[1:-1]
    fscore = []
    #distinct_value_indices = np.where(np.diff(y_score))[0]
    #threshold_idxs = np.r_[distinct_value_indices, len(y_score)-1]
    #threshold = np.array(y_score)[threshold_idxs]
    #print('threshold',threshold)
    y_score = list(y_score.reshape(-1))
    fun = lambda x: x[1] - x[0]
    listA = []
    lstA = [i for i,v in enumerate(y_true) if v==1]
    for k, g in groupby(enumerate(lstA), fun):
        listA.append([v for i, v in g])
    ground_num = len(listA)
    if ground_num == 0:
        return 0.0
    listA = sum(listA, [])
    #print('listA', listA)
    for the in y_score:
        listB = []
        tmp =  [1 if s >= the else 0 for s in y_score]
        lstB = [i for i,v in enumerate(tmp) if v==1]
        for k, g in groupby(enumerate(lstB), fun):
            listB.append([v for i, v in g])
        #print(the, y_score, tmp, lstB, listB)
        pred_num = len(listB)
        if flag == 'strict':
            correct_num = int(listA==listB)
        if flag == 'soft':
            listB = sum(listB, [])
            correct_num = len(set(listA).intersection(set(listB)))/len(set(listA).union(set(listB)))
            #print(listB, 'correct_num', correct_num, pred_num, ground_num)
        #print(correct_num, pred_num, ground_num)
        precision = correct_num/pred_num
        recall = correct_num/ground_num
        if precision + recall != 0:
            fscore.append(2*((precision*recall)/(precision+recall)))
    return max(fscore)

def my_fscore_unify(Y_true, Y_score, flag='soft'):
    thres = set(sum(Y_score, []))
    res = []
    #print('thres', thres)
    for the in thres:
        fscore = []
        for y_true, y_score in zip(Y_true, Y_score):
            tmp =  [1 if s >= the else 0 for s in y_score]
            #print(y_true, tmp)
            fscore.append(my_fscore_determine(y_true, tmp, flag))
        res.append(sum(fscore)/len(fscore))
    return max(res)

def my_fscore_determine(label_test, label_pred, flag='soft'):
    label_test, label_pred = label_test[1:-1], label_pred[1:-1]
    fun = lambda x: x[1] - x[0]
    listA, listB = [], []
    lstA = [i for i,v in enumerate(label_test) if v==1]
    lstB = [i for i,v in enumerate(label_pred) if v==1]
    for k, g in groupby(enumerate(lstA), fun):
        listA.append([v for i, v in g])
    for k, g in groupby(enumerate(lstB), fun):
        listB.append([v for i, v in g])
    ground_num = len(listA)
    pred_num = len(listB)
    if ground_num == 0 or pred_num == 0:
        return 0.0
    listA = sum(listA, [])
    listB = sum(listB, [])
    if flag == 'strict':
        correct_num = int(listA==listB)
    if flag == 'soft':
        correct_num = len(set(listA).intersection(set(listB)))/len(set(listA).union(set(listB)))
    precision = correct_num/pred_num
    recall = correct_num/ground_num
    if precision + recall != 0:
        #print('correct_num, pred_num, ground_num', listA, listB, correct_num, pred_num, ground_num)
        F1 = 2*((precision*recall)/(precision+recall))
        #print(label_test, label_pred, F1)
        return F1
    else:
        return 0.0
    
def noise_label_quality(LABEL, TEXT, SD):
    acc, count = 0, 0
    for label, text, sd in zip(LABEL, TEXT, SD):
        s, d = sd[0]
        if (s, d, tuple(text)) in groundtruth_table:
            count += 1
            if groundtruth_table[(s, d, tuple(text))] == label:
                acc += 1
            else:
                print('SD is', s, d, tuple(text))
                print('ground', groundtruth_table[(s, d, tuple(text))])
                print('noise', label)
    print('The noisy labelling quality is corrected {} over {} ({})'.format(acc, count, acc/count))
    
def auc_score(y_true, y_score):
    precision, recall, _ = precision_recall_curve(y_true, y_score)
    return auc(recall, precision)

def calc_angle_2(v1, v2): #0-360
    r = np.arccos(np.dot(v1, v2) / (np.linalg.norm(v1, 2) * np.linalg.norm(v2, 2)))
    deg = r * 180 / np.pi

    a1 = np.array([*v1, 0])
    a2 = np.array([*v2, 0])

    a3 = np.cross(a1, a2)

    if np.sign(a3[2]) > 0:
        deg = 360 - deg
    return deg

def ontain_angle_with_cpath_(key):
    traj = ogeom[key]
    angle_with_cpath = [0]
    for i in range(1, len(traj)-1):
        angle_with_cpath.append(calc_angle_2([traj[i][0]-traj[i-1][0], traj[i][1]- traj[i-1][1]], [traj[i+1][0]-traj[i][0], traj[i+1][1]- traj[i][1]]))
    angle_with_cpath.append(0)
    opath = raw_data[key]['o_path']
    angle_with_cpath_ = [angle_with_cpath[0]]
    opath_ = [opath[0]]
    for i in range(1, len(opath)):
        if opath[i] != opath[i-1]:
            angle_with_cpath_.append(angle_with_cpath[i])
            opath_.append(opath[i])
    #print(len(angle_with_cpath_), len(raw_data[key]['cpath']))
    #print(angle_with_cpath_, raw_data[key]['cpath'])
    fpts, bpts = 0, len(raw_data[key]['cpath'])
    for i in range(len(raw_data[key]['cpath'])):
        if i == len(opath_) - 1 or i == len(raw_data[key]['cpath']) - 1:
            fpts = i + 1
            break
        if opath_[i] != raw_data[key]['cpath'][i]:
            fpts = i
            break
    x = 0
    for i in reversed(range(fpts, len(raw_data[key]['cpath']))):
        x -= 1
        if -x == len(opath_) or i == fpts:
            bpts = i
            break
        if raw_data[key]['cpath'][i] != opath_[x]:
            bpts = i + 1
            break
    print('cpath, opath', raw_data[key]['cpath'], opath_, fpts, bpts, x)
    A = raw_data[key]['cpath']
    B = opath_[:fpts] + [opath_[fpts-1]]*max(0, bpts-fpts) +  ([] if len(raw_data[key]['cpath']) - bpts <= 0 else opath_[-(len(raw_data[key]['cpath'])-bpts):])
    C = angle_with_cpath_[:fpts] + [angle_with_cpath_[fpts-1]]*max(0, bpts-fpts) + ([] if len(raw_data[key]['cpath']) - bpts <= 0 else angle_with_cpath_[-(len(raw_data[key]['cpath'])-bpts):])
    print(A,B,C, len(A), len(B), len(C))
    if len(C) != len(A):
        print('a bug', println())
    return C

def ontain_angle_with_cpath(key):
    traj = ogeom[key]
    angle_with_cpath = [0]
    for i in range(1, len(traj)-1):
        angle_with_cpath.append(calc_angle_2([traj[i][0]-traj[i-1][0], traj[i][1]- traj[i-1][1]], [traj[i+1][0]-traj[i][0], traj[i+1][1]- traj[i][1]]))
    angle_with_cpath.append(0)
    opath = raw_data[key]['o_path']
    angle_with_cpath_ = [angle_with_cpath[0]]
    opath_ = [opath[0]]
    for i in range(1, len(opath)):
        if opath[i] != opath[i-1]:
            angle_with_cpath_.append(angle_with_cpath[i])
            opath_.append(opath[i])    
    return opath_, angle_with_cpath_

def SD_Data(slot=24, clean=5):
    SD_pair_data = {} #SD_{i,j} for i in |pairs| for j in |slots|
    SD_pair_time = {}
    SD_pair_key = {}
    SD_pair_angle = {}
    c = 0
    for key, value in raw_data.items():
        c+=1
        if c%5000 == 0:
            print('process', c, '/', len(raw_data))
        if value['match'] == False or len(value['cpath'])<2:
            continue
        pair = (value['cpath'][0], value['cpath'][-1])
        hour = time.localtime(value['tms'][0]).tm_hour
        opath, angle_with_cpath = ontain_angle_with_cpath(key)
        value['cpath'] = opath
        
        if pair in SD_pair_data:
            endidx = value['cpath'].index(pair[1])
            staidx = len(value['cpath'][0:endidx+1]) - 1 -  value['cpath'][0:endidx+1][::-1].index(pair[0])
            SD_pair_data[pair][hour%slot].append(value['cpath'][staidx:endidx+1])
            SD_pair_angle[pair][hour%slot].append(angle_with_cpath[staidx:endidx+1])
            SD_pair_time[pair][hour%slot].append(value['tms'][-1] - value['tms'][0])
            SD_pair_key[pair][hour%slot].append(key)
        else:
            SD_pair_data[pair] = [[] for i in range(slot)]
            SD_pair_angle[pair] = [[] for i in range(slot)]
            SD_pair_time[pair] = [[] for i in range(slot)]
            SD_pair_key[pair] = [[] for i in range(slot)]
            endidx = value['cpath'].index(pair[1])
            staidx = len(value['cpath'][0:endidx+1]) - 1 -  value['cpath'][0:endidx+1][::-1].index(pair[0])     
            SD_pair_data[pair][hour%slot].append(value['cpath'][staidx:endidx+1])
            SD_pair_angle[pair][hour%slot].append(angle_with_cpath[staidx:endidx+1])
            SD_pair_time[pair][hour%slot].append(value['tms'][-1] - value['tms'][0])
            SD_pair_key[pair][hour%slot].append(key)
    print('Done SD pair data and start clean')
    collect_clean = []
    for key, value in SD_pair_data.items():
        c = 0 
        for val in value:
            c+=len(val)
        if c < clean:
            collect_clean.append(key)
    for key in collect_clean:
        del SD_pair_data[key]
        del SD_pair_angle[key]
        del SD_pair_time[key]
        del SD_pair_key[key]
    return SD_pair_data, SD_pair_angle, SD_pair_time, SD_pair_key

def SD_distribution():
    SD_rows, SD_cols = {}, {}
    for key, value in SD_pair_data.items():
        SD_cols[key] = []
        for val in value:
            SD_cols[key].append(len(val))
        SD_rows[key] = sum(SD_cols[key])
    print('Done sample table')
    return SD_rows, SD_cols

def random_index(rate):
    start = 0
    index = 0
    randnum = random.randint(1, sum(rate))
    for index, scope in enumerate(rate):
        start += scope
        if randnum <= start:
            break
    return index

def get_normal_route():
    sample_pair, sample_slot = SD_sampling()
    normal_SD_set = SD_pair_data[sample_pair][sample_slot]
    #print('len', len(normal_SD_set))
    return normal_SD_set[random.randint(0, len(normal_SD_set)-1)]

def SD_sampling():
    SD_rows, SD_cols = sample_table[0], sample_table[1]
    PAIR = list(SD_rows.keys())
    index = random_index(SD_rows.values())
    sample_pair = PAIR[index]
    sample_slot = random_index(SD_cols[sample_pair])
    return sample_pair, sample_slot
    
def verify_distribution():
    A = {}
    for count in range(1000):
        sample_pair, sample_slot = SD_sampling()
        if sample_pair in A:
            A[sample_pair]+=1
        else:
            A[sample_pair]=1
    return A 

def get_travel_distance(route):
    travel = 0
    for a in route:
        travel += data_dict_chengdu['road_lengths'][a]
    return travel

def labelling(normal_route, detour_route, A, B):
    label = [0]*len(detour_route)
    normalS, normalD, detourS, detourD = -1, -1, -1, -1
    for i in range(A, len(detour_route)):
        if normal_route[i] != detour_route[i]:
            detourS = i
            normalS = i
            break
    for i in range(-len(detour_route)+B, -len(detour_route)-1, -1):
        if normal_route[i] != detour_route[i]:
            detourD = len(detour_route)+i
            normalD = len(normal_route)+i
            break
    label[detourS:detourD+1] = [1]*(detourD-detourS+1)
    return label, normalS, normalD, detourS, detourD
    
def get_detour_route(alpha=0.2):
    #print('detour')
    normal_route = get_normal_route()
    detour_len = max(int(len(normal_route)*alpha), 1)
    start = random.randint(0, int(len(normal_route)*0.5))
    A, B = start, start+detour_len
    normal_seg = normal_route[A:B+1]
    #print(normal_route, A, B, normal_seg)
    if normal_seg[0] not in G or normal_seg[-1] not in G:
        return []
    paths = list(nx.all_simple_paths(G, normal_seg[0], normal_seg[-1], 10))
    #print('Done paths', paths)
    for path in paths:
        if path != normal_seg and get_travel_distance(path) > get_travel_distance(normal_seg):
            detour_route = normal_route[0:A] + path + normal_route[B+1:len(normal_route)]
            label, normalS, normalD, detourS, detourD = labelling(normal_route, detour_route, A, A+len(path)-1)
            if normalS <= normalD and detourS <= detourD:
                return [normal_route, detour_route, label, normalS, normalD, detourS, detourD]
    return []

def ger_detour_batch(alpha=0.2, batch=10):
    count = batch
    detour_data_batch = []
    while count !=0 :
        tmp = get_detour_route(alpha)
        if tmp != []:
            detour_data_batch.append(tmp)
            count -= 1
    return detour_data_batch

def get_average_len(detour_data_batch):
    detour_len= 0
    for c in detour_data_batch:
        detour_len += (c[4]-c[3]+1)
    print('average detour len', detour_len/len(detour_data_batch))
    return detour_len/len(detour_data_batch)

def has_the_route_in_G(route):
    for r in route:
        if r not in G:
            return False
    return True

def is_decision(pre, suf, last_label):
    #output: is_decision, the decision label
    #print('pre, suf, last_label', pre, suf, last_label)
    #one-to-more
    if G.out_degree(pre)>1 and G.in_degree(suf)==1:
        #print('case one-to-more')
        if last_label==1:
            return [False, last_label]
        else:
            return [True, None]
    #one-to-one
    if G.out_degree(pre)==1 and G.in_degree(suf)==1:
        #print('case one-to-one')
        return [False, last_label]
    #more-to-one
    if G.out_degree(pre)==1 and G.in_degree(suf)>1:
        #print('case more-to-one')
        if last_label==0:
            return [False, last_label]
        else:
            return [True, None]
    #more-to-more
    if G.out_degree(pre)>1 and G.in_degree(suf)>1:
        #print('case more-to-more')
        return [True, None]
    #print('case unknow')
    return [True, None]

def get_noise_data_with_label_batch(batch_size=10): #prior+road_network
    noise_data_batch = []
    features_batch = []
    count = batch_size
    while count !=0 :
        sample_pair, sample_slot = SD_sampling()
        normal_SD_set = SD_pair_data[sample_pair][sample_slot]
        normal_SD_angle = SD_pair_angle[sample_pair][sample_slot]
        seed = random.randint(0, len(normal_SD_set)-1)
        route = normal_SD_set[seed]
        route_angle = normal_SD_angle[seed]
        #print(sample_pair, sample_slot, seed)
        fall = []
        if len(route) >= 2 and has_the_route_in_G(route):
            if len(route) != len(route_angle):
                println()
            for i in range(len(route)):
                speed = historical_average_speed[route[i]]
                level = sum(speed)*np.eye(5)[data_dict_chengdu['node2type'][route[i]]]
                #print('route_angle[i]',route_angle[i])
                if not math.isnan(route_angle[i]):
                    tangle = np.eye(8)[min(7, int(route_angle[i]/45))]
                else:
                    tangle = np.eye(8)[0]
                if i == 0:
                    fall = np.hstack([speed, level, tangle]).reshape(-1,1)
                else:
                    fall = np.hstack([fall, np.hstack([speed, level, tangle]).reshape(-1,1)])
            #print('fall', fall)
            #print('route', route)
            #println()
            noise_data_batch.append(route)
            features_batch.append(fall)
            count -= 1
    return noise_data_batch, features_batch

def get_feature(text):
    features_batch = []
    for route in text:
        fall = []
        for i in range(len(route)):
            if route[i] not in historical_average_speed:
                continue
            speed = historical_average_speed[route[i]]            
            if route[i] not in nodetype: #data_dict_chengdu['node2type']:
                level = sum(speed)*np.eye(5)[0]
            else:
                level = sum(speed)*np.eye(5)[nodetype[route[i]]]#data_dict_chengdu['node2type']
            if i == 0 or i == len(route) - 1:
                tangle = np.eye(8)[0]
            elif (route[i-1], route[i]) in historical_average_angle:
                tangle = historical_average_angle[(route[i-1], route[i])]
            else:
                tangle = np.eye(8)[0]
            if i == 0:
                fall = np.hstack([speed, level, tangle]).reshape(-1,1)
            else:
                fall = np.hstack([fall, np.hstack([speed, level, tangle]).reshape(-1,1)])
        features_batch.append(fall)
    return features_batch

def load_data(batch_size):
    noise_data_batch, features_batch = get_noise_data_with_label_batch(batch_size)
    return noise_data_batch, features_batch

def build_embed(symbols, embed_units):
    print("Loading word vectors...")
    embed = np.zeros([symbols, embed_units], dtype=np.float32)
    for key in w2v_toast.vocab.keys():
        if key == 'PAD' or key == 'MASK':
            continue
        embed[int(key)] = w2v_toast[key]
    return embed

def load_data_groundtruth(batch_size):
    #get noise labelling with prior_knowledge
    label, text, features_batch = [], [], []
    manual = batch_size
    while manual:
        sample_pair, sample_slot = SD_sampling()
        trajs = SD_pair_data[sample_pair][sample_slot]
        seed = random.randint(0, len(trajs)-1)
        traj = tuple(trajs[seed])
        normal_SD_angle = SD_pair_angle[sample_pair][sample_slot]
        route_angle = normal_SD_angle[seed]
        
        if (sample_pair[0],sample_pair[1],traj) not in groundtruth_table or not has_the_route_in_G(traj):
            continue
        label.append(groundtruth_table[(sample_pair[0],sample_pair[1],traj)])
        route = list(traj)
        text.append(route)
        fall = []
        for i in range(len(route)):
            speed = historical_average_speed[route[i]]
            level = sum(speed)*np.eye(5)[data_dict_chengdu['node2type'][route[i]]]
            if not math.isnan(route_angle[i]):
                tangle = np.eye(8)[min(7, int(route_angle[i]/45))]
            else:
                tangle = np.eye(8)[0]
            if i == 0:
                fall = np.hstack([speed, level, tangle]).reshape(-1,1)
            else:
                fall = np.hstack([fall, np.hstack([speed, level, tangle]).reshape(-1,1)])
        features_batch.append(fall)
        manual-=1        
    return label, text, features_batch

def obtain_groundtruth():
    file_list = []
    dir_list = []
    groundtruth_table = {}
    file_list, dir_list = get_file_path(groundtruth_path, file_list, dir_list)
    NUM, NUM_detour = 0, 0
    abroads, roads = 0, 0
    for fl in file_list:
        tmp = fl.split(groundtruth_path)[1]
        if '.txt' not in tmp:
            continue
        tmp_ = tmp.split('_')
        S, D, num = int(tmp_[0]), int(tmp_[1]), int(tmp_[3])
        NUM+=num
        f = open(fl)
        line_count = 0
        traj, label = [],[]
        line_tmp = ''
        for line in f:
            line_count+=1
            if line_count == 1:
                line_tmp = line
                continue
            temp = line.strip().split(',')
            traj.append(int(temp[0]))
            label.append(int(temp[1]))
        if sum(label)>0:
            NUM_detour+=int(line_tmp.split(' ')[4])
            abroads += (sum(label)*int(line_tmp.split(' ')[4]))
        roads += (len(traj)*num)
        f.close()
        groundtruth_table[(S,D,tuple(traj))] = label
    print('There are {} detours (with {} abnormal raods) in total {} paths (with {} roads)'.format(NUM_detour,abroads,NUM,roads))
    return groundtruth_table

def refine_groundtruth(groundtruth_table):
    re_groundtruth_table = {}
    record = []
    for key, label in groundtruth_table.items():
        route = key[2]
        if has_the_route_in_G(tuple(route)):
            relabel = [0]
            for i in range(1, len(route)-1):
                is_dec, tag = is_decision(route[i-1], route[i], relabel[i-1])
                if is_dec:
                    relabel.append(label[i])
                else:
                    relabel.append(tag)    
            relabel.append(0)
            re_groundtruth_table[key] = relabel
            if relabel != label:
                record.append([key, label, relabel])
        else:
            print('not in G')
            re_groundtruth_table[key] = label
    return re_groundtruth_table, record

def read_location_ogeom(path):
    f = open(path)
    c = 0
    ogeom = {}
    for line in f:
        c += 1
        if c == 1:
            continue
        tmp = line.split(';')
        loc_ = tmp[1][12:-1].split(',')
        loc = []
        for item in loc_:
            item_ = item.split(' ')
            loc.append([float(item_[0]), float(item_[1])])
        ogeom[int(tmp[0])] = loc
    return ogeom

def obtain_historical_average_speed():
    historical_average_speed = {}
    c = 0
    for key, value in raw_data.items():
        c+=1
        if c%10000 == 0:
            print('process', c, '/', len(raw_data))
        if value['match'] == False or len(value['cpath'])<2:
            continue
        for index, op in enumerate(value['o_path']):
            if op in historical_average_speed:
                historical_average_speed[op].append(value['speed'][index])
            else:
                historical_average_speed[op] = [value['speed'][index]]
    for key, value in historical_average_speed.items():
        historical_average_speed[key] = sum(historical_average_speed[key])/len(historical_average_speed[key])
    max_speed, min_speed = max(list(historical_average_speed.values())), min(list(historical_average_speed.values()))
    span = (max_speed-min_speed)/3.0
    for key, value in historical_average_speed.items():
        if historical_average_speed[key] >= min_speed and historical_average_speed[key] < min_speed + span:
            historical_average_speed[key] = np.array([historical_average_speed[key]/max_speed, 0, 0])
        elif historical_average_speed[key] >= min_speed + span and historical_average_speed[key] <= min_speed + 2*span:
            historical_average_speed[key] = np.array([0, historical_average_speed[key]/max_speed, 0])
        else:
            historical_average_speed[key] = np.array([0, 0, historical_average_speed[key]/max_speed])
    
    return historical_average_speed

def obtain_historical_average_angle_():
    historical_average_angle = {}
    c = 0
    for key, value in raw_data.items():
        c+=1
        if c%10000 == 0:
            print('process', c, '/', len(raw_data))
        if value['match'] == False or len(value['cpath'])<2:
            continue
        opath, angle_with_cpath = ontain_angle_with_cpath(key)
        for index, op in enumerate(opath):
            if op in historical_average_angle:
                historical_average_angle[op].append(angle_with_cpath[index])
            else:
                historical_average_angle[op] = [angle_with_cpath[index]]
    for key, value in historical_average_angle.items():
        historical_average_angle[key] = sum(historical_average_angle[key])/len(historical_average_angle[key])

    for key, value in historical_average_angle.items():
        if not math.isnan(historical_average_angle[key]):
            historical_average_angle[key] = np.eye(8)[min(7, int(historical_average_angle[key]/45))]
        else:
            historical_average_angle[key] = np.eye(8)[0]
            
    return historical_average_angle

def obtain_historical_average_angle():
    historical_average_angle = {}
    c = 0
    for key, value in raw_data.items():
        c+=1
        if c%10000 == 0:
            print('process', c, '/', len(raw_data))
        if value['match'] == False or len(value['cpath'])<2:
            continue
        traj = ogeom[key]
        opath = raw_data[key]['o_path']
        for i in range(1, len(traj)-1):
            angle = calc_angle_2([traj[i][0]-traj[i-1][0], traj[i][1]- traj[i-1][1]], [traj[i+1][0]-traj[i][0], traj[i+1][1]- traj[i][1]])
            if (opath[i-1], opath[i]) in historical_average_angle:    
                historical_average_angle[(opath[i-1], opath[i])].append(angle)
            else:
                historical_average_angle[(opath[i-1], opath[i])] = [angle]
    for key, value in historical_average_angle.items():
        tmp_ = sum(historical_average_angle[key])/len(historical_average_angle[key])
        if not math.isnan(tmp_):
            historical_average_angle[key] = np.eye(8)[min(7, int(tmp_/45))]
        else:
            historical_average_angle[key] = np.eye(8)[0]        
    return historical_average_angle


if __name__ == '__main__':
    txt_path = 'C:/Users/wang_zheng/Downloads/HP-backup/compression-data/chengdu-mapmatching/result_1101.txt'
    #ogeom = read_location_ogeom(txt_path)
    #pickle.dump(ogeom, open(traj_chengdu_path+'ogeom', 'wb'), protocol=2)
    ogeom = pickle.load(open(traj_chengdu_path+'ogeom', 'rb'), encoding='bytes')
    #print(calc_angle_2([1, 0], [0, 1]))
    raw_data = pickle.load(open(traj_chengdu_path+'20161101.pickle', 'rb'), encoding='bytes')
    #historical_average_speed = obtain_historical_average_speed()
    historical_average_angle = obtain_historical_average_angle()
    pickle.dump(historical_average_angle, open(traj_chengdu_path+'historical_average_angle', 'wb'), protocol=2)
    #pickle.dump(historical_average_speed, open(traj_chengdu_path+'historical_average_speed', 'wb'), protocol=2)
    #SD_pair_data, SD_pair_angle, SD_pair_time, SD_pair_key = SD_Data(slot)
    #pickle.dump(SD_pair_data, open(traj_chengdu_path+'SD_pair_data', 'wb'), protocol=2)
    #pickle.dump(SD_pair_angle, open(traj_chengdu_path+'SD_pair_angle', 'wb'), protocol=2)
    #pickle.dump(SD_pair_time, open(traj_chengdu_path+'SD_pair_time', 'wb'), protocol=2)
    #pickle.dump(SD_pair_key, open(traj_chengdu_path+'SD_pair_key', 'wb'), protocol=2)

#unify thres labelling =  0.5314416967556582