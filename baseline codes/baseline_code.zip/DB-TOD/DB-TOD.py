# -*- coding: utf-8 -*-
"""
Created on Thu Aug 19 14:33:04 2021

@author: wang_zheng
"""

import numpy as np
import time
import data_utils as F
from data_utils import G, nodetype, data_dict_chengdu, historical_average_speed, historical_average_angle, my_fscore, SD_pair_data
import random
import networkx as nx
import pickle

traj_chengdu_path = 'C:/Users/wang_zheng/Downloads/HP-backup/compression-data/chengdu-pickle/PN/efficiency_group_data/'
traj_chengdu_path = 'C:/Users/wang_zheng/Downloads/HP-backup/compression-data/chengdu-pickle/'
traj_chengdu_path = 'C:/Users/wang_zheng/Downloads/HP-backup/compression-data/xian-pickle/PN/efficiency_group_data/'

np.random.seed(0)

globaltime = str(time.time())

TEXT_TRAIN = pickle.load(open(traj_chengdu_path+'train_data.pickle', 'rb'), encoding='bytes')
LABEL_TRAIN = pickle.load(open(traj_chengdu_path+'train_label.pickle', 'rb'), encoding='bytes')
FEATURE_TRAIN = F.get_feature(TEXT_TRAIN)

#theta, delta = np.random.rand(16), np.random.rand(max(G.nodes())+1)
theta, delta = np.random.uniform(-1, 1, (16,)), np.random.uniform(-1, 1, (max(G.nodes())+1,))
epoch = 10
T_step = 10
gamma = 0.95

def Z_equal(S, D, T=10):
    if S == D:
        paths = [[S]]
    else:
        paths = list(nx.all_simple_paths(G, S, D, T-1))
    Z = 0.0
    for path in paths:
        if len(path) == T:
            fall = F.get_feature([path])[0]
            Z += np.exp(-np.dot(theta, np.sum(fall, axis=1)))
    return Z
            
def Z_samll_than(S, D, T=10):
    if S == D:
        paths = [[S]]
    else:
        paths = list(nx.all_simple_paths(G, S, D, T-1))
    Z = 0.0
    for path in paths:
        fall = F.get_feature([path])[0]
        Z += np.exp(-np.dot(theta, np.sum(fall, axis=1)))
    return Z

def testing(TEXT_TEST, LABEL_TEST, FEATURE_TEST):
    #labelling_prauc = []
    start = time.time()
    detoutc = 0
    Label_Test, Output_Score = [], [] 
    for label_test, text_test, feature_test in zip(LABEL_TEST, TEXT_TEST, FEATURE_TEST):
        text_test = list(text_test)
        if sum(label_test) > 0:
            detoutc += 1
            outputs = []
            #print('feature_test', feature_test)
            for i in range(len(text_test)):
                outputs.append(np.dot(theta, np.sum(feature_test[:,:i+1], axis=1)) + sum(delta[text_test[:i+1]]))
            #print('outputs', outputs, theta, sum(delta[text_test]))
            #labelling_prauc.append(my_fscore(label_test, np.array(outputs)))
            Label_Test.append(label_test)
            Output_Score.append(outputs)
    #print('labelling =', sum(labelling_prauc)/len(labelling_prauc), detoutc)
    print('time', (time.time()-start)/len(TEXT_TEST))#
    print('unify thres labelling = ', F.my_fscore_unify(Label_Test, Output_Score))
#    unify thres labelling =  0.5193223443223445/250
#    time 0.3979370594024658
#    unify thres labelling =  0.4479844413012733/250
#    time 1.7084341049194336
#    unify thres labelling =  0.4407399726969865/250
#    time 3.5874133110046387
#    unify thres labelling =  0.4828962224889158/260
#    time 11.581051349639893

def obtain_actions(S, D):
    SD = sum(SD_pair_data[(S,D)], [])
    T_step = []
    actions = []
    for item in SD:
        T_step.append(len(item))
        for a in item:
            if a != S and a != D:
                actions.append(a)
    return actions#, max(T_step) + 1

epoch = 0

def testing_main():
    '''
    for i in ['lerned-classifier-data2', 'lerned-classifier-data3', 'lerned-classifier-data4', 'lerned-classifier-data5']:
        start = time.time()
        [LABEL_TEST, TEXT_TEST] = pickle.load(open(traj_chengdu_path+i, 'rb'), encoding='bytes')
        FEATURE_TEST = F.get_feature(TEXT_TEST)
        testing(TEXT_TEST,LABEL_TEST,FEATURE_TEST)
        print('time', (time.time()-start))
    '''
    for i in [('g1_data.pickle','g1_label.pickle'),
              ('g2_data.pickle','g2_label.pickle'),
              ('g3_data.pickle','g3_label.pickle'),
              ('g4_data.pickle','g4_label.pickle')]:
        #start = time.time()
        TEXT_TEST = pickle.load(open(traj_chengdu_path+i[0], 'rb'), encoding='bytes')
        LABEL_TEST = pickle.load(open(traj_chengdu_path+i[1], 'rb'), encoding='bytes')
        FEATURE_TEST = F.get_feature(TEXT_TEST)
        testing(TEXT_TEST,LABEL_TEST,FEATURE_TEST)
        #print('time', (time.time()-start)/len(TEXT_TEST))
    
    
for text_train, feature_train in zip(TEXT_TRAIN, FEATURE_TRAIN):
    S, D = text_train[0], text_train[-1]
    actions = obtain_actions(S, D)
    
    fr = np.sum(feature_train, axis=1).reshape(-1, 1)
    epoch += 1
    print('======= epoch', epoch, '=======')
    part2 = Z_samll_than(S, D, T_step)
    if part2 == 0:
        continue
    for a_idx, a in enumerate(actions):
        if a not in G:
            continue
        speed = historical_average_speed[a]
        if a not in nodetype:#data_dict_chengdu['node2type']:
            level = sum(speed)*np.eye(5)[0]
        else:
            level = sum(speed)*np.eye(5)[nodetype[a]]# data_dict_chengdu['node2type']
        
        if a_idx == 0 or a_idx == len(actions) - 1:
            tangle = np.eye(8)[0]
        elif (actions[a_idx-1], actions[a_idx]) in historical_average_angle:
            tangle = historical_average_angle[(actions[a_idx-1], actions[a_idx])]
        else:
            tangle = np.eye(8)[0]

        fa = np.hstack([speed, level, tangle]).reshape(-1,1)
        part1 = []
        #print('action', a_idx, a, 'sum_theta', sum(theta))
        
        for t in range(1, T_step):
            pp1 = Z_equal(S,a,t)
            pp2 = np.exp(-np.dot(theta, fa))[0]
            pp3 = Z_samll_than(a,D,T_step-t-1)
            #print('pp1,pp2,pp3',pp1,pp2,pp3)
            part1.append(pp1*pp2*pp3)
        #print(part1)
        part1 = sum(part1)
        #if part1 == 0.0:
        #    break
        #print('part1, part2', part1, part2)
        Dbar = part1/part2
        #print('Dbar', Dbar)
        delta[actions] = np.clip(delta[actions]*np.exp(gamma/epoch*(len(text_train) - Dbar)), -1, 1)
        if a_idx == 0:
            fa_ = fa * Dbar
        else:
            fa_ += (fa * Dbar)
    theta = np.clip(theta*np.exp(gamma/epoch*(fr-fa_)).reshape(-1), -1, 1)
    #print(fr, fa_, theta)
    testing_main()
    # best result 0.5893781032821235 with TEST-100
    pickle.dump(delta, open(traj_chengdu_path+'delta', 'wb'), protocol=2)
    pickle.dump(theta, open(traj_chengdu_path+'theta', 'wb'), protocol=2)
#my_prauc labelling = 0.1781767841962276 20   
#my_fscore labelling = 0.6815285688426831 20
#unify thres labelling =  0.5750078695459131
# 0.6165016127265851

    
    
    
    
    
    
    
    
    
    
    